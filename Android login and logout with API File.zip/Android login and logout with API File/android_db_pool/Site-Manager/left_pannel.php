<link rel="stylesheet" media="screen, print, handheld" type="text/css" href="css/calendar.css" />
<script type="text/javascript" src="js/calendar.js"></script>

<div class="mid_left_panel">
<div class="Add_area">

<img src="images/add_part.png" width="227" height="190" /></div>
<div class="Clock">



<div style="border:solid 1px #000;">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="middle">

<script type="text/javascript">
calendar();
</script>


</td>
<td align="left" valign="middle">

<iframe src="http://free.timeanddate.com/clock/i35itllo/n136/szw80/szh80/hoc000/hbw2/cf100/hncc5cfd1/fdi78/mqc000/mql10/mqw4/mqd98/mhc000/mhl10/mhw4/mhd98/mmc000/mml10/mmw1/mmd98/hwm2/hsc000" frameborder="0" width="82" height="82"></iframe>


</td>
</tr>
</table>
</div>

	

</div>
</div>
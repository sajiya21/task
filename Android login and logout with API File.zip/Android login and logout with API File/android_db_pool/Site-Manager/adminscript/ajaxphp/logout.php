<?php
session_start();
include("../include/function.inc.php");
$ff=new Functions();
$ff->logOut();


?>
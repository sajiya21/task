<style type="text/css">
<!--
a:link {
	color: #7B74BA;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
	color: #00F;
}
a:active {
	text-decoration: none;
}
-->chngPwd
</style>

<a href="javascript:chngPwd();">Change Password</a> |

<a href="javascript:logOut();">Logout</a>
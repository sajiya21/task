<ul id="nav">
	
          <li><a href="home.php">HOME</a>
                   
           </li>


    
            <li><a href="#">MASTER</a>         
              <ul>
                 <!-- <li><a href="#">Product</a>
                  <ul>
                  <li><a href="add_product.php">Add Product</a></li>
                   <li><a href="modify_product.php">Modify Product</a></li>
                  </ul>
                  </li>
                  
                  <li><a href="#">Machinaries</a>
                   <ul>
                  <li><a href="add_machinaries.php">Add Machinaries</a></li>
                   <li><a href="modify_machinaries.php">Modify Machinaries</a></li>
                  </ul>
                  </li>-->

                  <li><a href="#">Events</a>
                  <ul>
		                  <li><a href="add_events.php">Add Events</a></li>
		                  <li><a href="modify_events.php">Modify Events</a></li>
                   </ul>
                   </li>
                   
                   
                  <li><a href="#">Music</a>
                  <ul>
		                  <li><a href="add_music.php">Add music</a></li>
		                  <li><a href="modify_music.php">Modify music</a></li>
                   </ul>
                   </li>
                   
                   
                 <li><a href="#">Videos</a>
                 <ul>
                 <li><a href="add_video.php">Add video</a></li>
                 <li><a href="modify_video.php">Modify Video</a></li>
                 </ul>
                 </li>
                 
                       
                  <li><a href="#">Banners</a>
                  		 <ul>
                        <li><a href="add_banner.php">Add Banner</a></li>
                        <li><a href="modify_banner.php">Modify Banner</a></li>
                        </ul>
              </li>
                  
                  
<!--                  <li>
                  <a href="#">Biodata</a>
                 <ul>
                        <li><a href="add_biodata.php">Add Bio-data</a></li>
                        <li><a href="modify_biodata.php">Modify Bio-dat</a></li>
                        </ul>
                  </li>-->
                  <li><a href="#">Gallery</a>
                  <ul>
                     <li><a href="#">Arnab's Gallery</a>
                     <ul>
                     <li><a href="add_abhi_gallery.php">Add Images</a></li>
                     <li><a href="modify_abhi_gallery.php">Modiy Images</a></li>
                     </ul>
                     </li>
                     <li><a href="#">Legend's Gallery</a>
                     <ul>
                     <li><a href="add_legend_gallery.php">Add Images</a></li>
                     <li><a href="modify_legend_gallery.php">Modify Images</a></li>
                     </ul>
                     </li>
                     <li><a href="#">Press Gallery</a>
                     <ul>
                      <li><a href="add_press_gallery.php">Add Images</a></li>
                     <li><a href="modify_press_gallery.php">Modify Images</a></li>
                     </ul>
                     </li>
                  </ul>
                  </li>
                  
                  <li><a href="manage_logo.php">Logo</a></li>
                  
                  <li>
                  <a href="#">Testimonial</a>
                  <ul>
                  <li><a href="add_testi.php">Add Testimonials</a></li>
                  <li><a href="modify_testi.php">Modify Testimonials</a></li>
                  </ul>
                  </li>
                  
                   <li>
                  <a href="#">Manage Gharana info</a>
                  <ul>
                  <li><a href="add_aboutme.php">Add Gharana</a></li>
                  <li><a href="modify_aboutme.php">Modify Gharana</a></li>
                  </ul>
                  </li>
                  
                  <li>
                  <a href="#">About Me</a>
                  <ul>
                  <li><a href="add_biodata.php">Add biodata</a></li>
                  <li><a href="modify_biodata.php">Modify biodata</a></li>
                  </ul>
                  </li>
                  
             </ul>           
           </li>
    
          
           <li><a href="#">CMS</a>
               <ul>
                <li><a href="modify_explore.php">Modify Explore</a></li>
                <li><a href="modify_home.php">Modify Home</a></li>
                <li><a href="modify_contacts.php">Modify Contacts</a></li>
               </ul>         
           </li>

    
           <li><a href="#">ENQUIRY</a>           
               <ul>
                   <li><a href="manage_enquiry.php">Manage Enquiry</a></li>
                   <li><a href="#">--------</a></li>
              </ul>         
          </li>
     
     
     
     
    
     </li>
     
    
    
</ul>
<div class="footerLine"></div>
<div class="footer">
Powered By : <a href="http://www.websyntax.info/" target="_blank" style="color:#FFF; text-decoration:none;">WebSyntax</a>
</div>
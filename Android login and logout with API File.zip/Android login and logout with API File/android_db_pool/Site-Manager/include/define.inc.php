<?php
	// Predefine Constant Variable
	// Client Email Address
	define("CLIENT_EMAIL","admin@nicgravy.com",true);
	// Admin Panel Header
	define("ADMIN_HEADER","Admin Control Panel",true);
	// Admin Page Title
	define("ADMIN_PAGE_TITLE",":::Nicgravy Admin:::",true);
	// User Page Title
	define("USER_PAGE_TITLE",":::Welcome to Nicgravy:::",true);
	//user admin footer/////
	define("USER_ADMIN_PAGE_FOOTER","<span class=\"footer-text2\">&copy;2007-2009 Nicgravy - All rights reserved.<br />
  Website Design by </span><a href=\"#\" class=\"footer-text2\">digitalwebkreation</a>",true);
	// No of record for pagging
	define("PAGGING_RECORD","50",true);
	// Website URL
	define("WEB_URL","localhost",true);
	// Mail SMTP Address
	define("SMTP_SERVER","",true);
	// Mail Authentic Username
	define("SMTP_AUTH_USERNAME","",true);
	// Mail Authentic Password
	define("SMTP_AUTH_PASSWORD","",true);
	//Definition of Tables 
	define("ADMIN","`blueparking_tbl_admin`",true);
	define("BANNER","`tbl_banner`",true);
	define("BILINFO","`tbl_billing_info`",true);
	define("CATEGORY","`tbl_category`",true);
	define("CONTROL","`tbl_control_page`",true);
	define("COUNTRY","`tbl_country`",true);
	define("CPNUSER","`tbl_coupon_user`",true);
	define("GROUP","`tbl_email_group`",true);
	define("USERINFO","`tbl_userinfo`",true);
	define("USERLOG","`tbl_userlogin`",true);
	define("WHOLESELLERINFO","`tbl_wholeSellerinfo`",true);
	define("WHOLESELLERLOG","`tbl_wholeSellerlogin`",true);
	define("FORDER","`tbl_final_order`",true);
	define("BLFORDER","`tbl_final_order_bill`",true);
	define("DTFORDER","`tbl_final_order_details`",true);
	define("CFORDER","`tbl_final_order_cc`",true);
	define("SFORDER","`tbl_final_order_ship`",true);
	define("HEADER","`tbl_header`",true);
	define("LOGO","`tbl_logo`",true);
	define("MNHOME","`tbl_main_display_home`",true);
	define("MNNAV","`tbl_main_nevigation`",true);
	define("NEWS_CONTENT","`tbl_newsletter`",true);
	define("PROD","`tbl_product`",true);
	define("PRODCAT","`tbl_product_category`",true);
	define("PRODCPN","`tbl_product_coupon`",true);
	define("PRODISP","`tbl_product_display_option`",true);
	define("PRODIMG","`tbl_product_image`",true);
	define("PRODRVW","`tbl_review_product`",true);
	define("SHIP","`tbl_shipping`",true);
	define("STATE","`tbl_state`",true);
	define("TAX","`tbl_tax`",true);
	define("TMPCRT","`tbl_temp_cart`",true);
	define("TMPPROD","`tbl_temp_product`",true);
	define("TMPORD","`tbl_temp_order`",true);
	define("USRACC","`tbl_user_account`",true);
	define("NEWSLETTER","`tbl_email_newsletter`",true);
	define("CONTENT","`tbl_content`",true);
	define("PAGE_CONTROL","`tbl_page_control`",true);
	define("TBL_REFERRAL","`tbl_referral`",true);
	define("TBL_THEME","`tbl_theme`",true);
	define("WISHLIST","`tbl_wishlist`",true); 
	define("BLOG","`tbl_blog`",true); 
	define("DB_BACKUP","`tbl_database_backup`",true); 
	 
?>
  <link rel="stylesheet" type="text/css" href="css/style.css"   />
<div class="header">
<div class="logo">
<img src="images/logotabla.png" width="213" height="135"/>
</div>
<div class="right_header_part">
<div class="top_menu_wrapper">
<div class="top_menu_left"></div>
<div class="top_menu_nav">
<ul>
<li style="background:none;">Welcome <?php echo $_SESSION['admin_name']; ?>, </li>
<li style="background:none;"><a href="home.php">Dashboard</a></li>
<li><a href="#" target="_blank">Viewsite</a></li>
<li><a href="logout.php" class="logout">Logout</a></li>
</ul>

</div>
<div class="top_menu_rightt"></div>
<div class="clear"></div>
</div>
<div class="clear"></div>
<div class="head_text">
Sign In To Your Site Management System</div>

</div>
</div>
